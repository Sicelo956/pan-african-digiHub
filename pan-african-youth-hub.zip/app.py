from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime

app = Flask(__name__)
CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///panafricanhub.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(120), unique=True)
    country = db.Column(db.String(50))
    interests = db.Column(db.String(250))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Opportunity(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    description = db.Column(db.Text)
    category = db.Column(db.String(50))
    deadline = db.Column(db.DateTime)
    link = db.Column(db.String(255))

class LearningResource(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100))
    content_type = db.Column(db.String(50))
    url = db.Column(db.String(255))
    tags = db.Column(db.String(150))

class Mentorship(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    mentor_name = db.Column(db.String(100))
    expertise_area = db.Column(db.String(100))
    bio = db.Column(db.Text)
    contact_email = db.Column(db.String(120))

@app.route('/')
def index():
    return jsonify({"message": "Pan-African Youth Digital Hub Backend API"})

@app.route('/users', methods=['POST'])
def create_user():
    data = request.json
    user = User(name=data['name'], email=data['email'], country=data['country'], interests=data['interests'])
    db.session.add(user)
    db.session.commit()
    return jsonify({"message": "User created successfully."})

@app.route('/opportunities', methods=['GET'])
def get_opportunities():
    opps = Opportunity.query.all()
    return jsonify([{ 'id': o.id, 'title': o.title, 'description': o.description, 'category': o.category, 'deadline': o.deadline.isoformat(), 'link': o.link } for o in opps])

@app.route('/learning', methods=['GET'])
def get_learning():
    resources = LearningResource.query.all()
    return jsonify([{ 'id': r.id, 'title': r.title, 'content_type': r.content_type, 'url': r.url, 'tags': r.tags } for r in resources])

@app.route('/mentors', methods=['GET'])
def get_mentors():
    mentors = Mentorship.query.all()
    return jsonify([{ 'id': m.id, 'mentor_name': m.mentor_name, 'expertise_area': m.expertise_area, 'bio': m.bio, 'contact_email': m.contact_email } for m in mentors])

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
